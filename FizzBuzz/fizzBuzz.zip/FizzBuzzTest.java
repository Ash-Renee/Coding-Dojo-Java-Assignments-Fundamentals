public class FizzBuzzTest {
    public static void main(String[] args){
        fizzBuzz iD = new fizzBuzz();
        String fizzBuzz = iD.fizzBuzz(5);
        System.out.println(fizzBuzz);
    }
}